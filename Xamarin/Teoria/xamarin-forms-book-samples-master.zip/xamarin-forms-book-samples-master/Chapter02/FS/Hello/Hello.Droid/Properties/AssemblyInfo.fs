namespace Hello.Droid
module AssemblyInfo =

  open System.Reflection
  open System.Runtime.CompilerServices
  open Android.App

  // Information about this assembly is defined by the following attributes. 
  // Change these attribute values to modify the information
  // associated with an assembly.

  [<assembly: AssemblyTitle("Hello.Droid")>]
  [<assembly: AssemblyDescription("")>]
  [<assembly: AssemblyConfiguration("")>]
  [<assembly: AssemblyCompany("")>]
  [<assembly: AssemblyProduct("Hello.Droid")>]
  [<assembly: AssemblyCopyright("Copyright ©  2015")>]
  [<assembly: AssemblyTrademark("")>]
  [<assembly: AssemblyCulture("")>]

  // The assembly version has the format "{Major}.{Minor}.{Build}.{Revision}".
  // The form "{Major}.{Minor}.*" will automatically update the build and revision,
  // and "{Major}.{Minor}.{Build}.*" will update just the revision.

  [<assembly: AssemblyVersion("1.0.0.0")>]

  // The following attributes are used to specify the signing key for the assembly, 
  // if desired. See the Mono documentation for more information about signing.

  //[<assembly: AssemblyDelaySign(false)>]
  //[<assembly: AssemblyKeyFile("")>]

  ()


