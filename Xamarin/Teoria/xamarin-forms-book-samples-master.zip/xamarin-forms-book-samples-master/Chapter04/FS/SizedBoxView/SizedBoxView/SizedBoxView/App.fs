namespace SizedBoxView

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = SizedBoxViewPage())

