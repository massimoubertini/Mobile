namespace ReflectedColors

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = ReflectedColorsPage())

