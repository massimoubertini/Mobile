namespace ColorList

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = ColorListPage())

