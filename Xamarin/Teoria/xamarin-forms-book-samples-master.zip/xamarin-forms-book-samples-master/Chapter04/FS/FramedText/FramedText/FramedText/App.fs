namespace FramedText

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = FramedTextPage())

