namespace BlackCat

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = BlackCatPage())

