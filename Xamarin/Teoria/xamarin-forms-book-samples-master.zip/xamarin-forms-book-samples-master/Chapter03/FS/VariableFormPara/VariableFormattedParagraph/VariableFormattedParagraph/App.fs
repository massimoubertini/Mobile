namespace VariableFormattedParagraph

open Xamarin.Forms

type App() = 
    inherit Application(MainPage = VariableFormattedParagraphPage())

